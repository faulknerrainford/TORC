"""
TORC project

"""

__version__ = "0.1"
__author__ = "Penn Faulkner Rainford"
__credits__ = ["YCCSA, University of York", "TORC project, EPSRC"]